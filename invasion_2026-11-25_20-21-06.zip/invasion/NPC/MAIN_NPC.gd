

extends CharacterBody2D

var speed = 50
var direction = Vector2.RIGHT
var stopped = false
var dead = false

var damage_cooldown = 0.0
var damage = 10
var min_x = -50
var max_x = 50
var min_y = -50
var max_y = 50

@onready var anim = $AnimatedSprite2D


func _ready():
	anim.animation_finished.connect(_on_animation_finished)
	random_walk()


func random_walk():
	while true:
		if dead:
			return

		direction = [
			Vector2.RIGHT,
			Vector2.LEFT,
			Vector2.UP,
			Vector2.DOWN
		].pick_random()

		stopped = false
		await get_tree().create_timer(2).timeout

		if dead:
			return

		stopped = true
		await get_tree().create_timer(2).timeout



func _physics_process(delta):
	if dead:
		velocity = Vector2.ZERO
		return

	if damage_cooldown > 0:
		damage_cooldown -= delta

	var player = get_tree().get_first_node_in_group("Player")

	if player == null:
		velocity = Vector2.ZERO
		anim.play("IDLE")
		return

	var distance = global_position.distance_to(player.global_position)
	var direction = (player.global_position - global_position).normalized()

	if distance > 35:
		velocity = direction * speed
		anim.play("WALK")
		move_and_slide()
	else:
		velocity = Vector2.ZERO
		move_and_slide()

		if damage_cooldown <= 0:
			anim.play("ATTACK")
			player.take_damage(damage)
			damage_cooldown = 1.0


	if stopped:
		velocity = Vector2.ZERO
		anim.play("IDLE")
	else:
		velocity = direction * speed
		anim.play("WALK")

	move_and_slide()

	if position.x > max_x:
		direction = Vector2.LEFT
	if position.x < min_x:
		direction = Vector2.RIGHT
	if position.y > max_y:
		direction = Vector2.UP
	if position.y < min_y:
		direction = Vector2.DOWN


func die():
	if dead:
		return

	dead = true
	velocity = Vector2.ZERO
	anim.play("DEAD")


func _on_animation_finished():
	if anim.animation == "DEAD":
		queue_free()


func _on_area_2d_area_entered(area: Area2D) -> void:
	if area.is_in_group("bullets"):
		die()
